/* eslint-disable  func-names */
/* eslint quote-props: ["error", "consistent"]*/
module.exports = {
    PROMPTS_IN_ENGLISH: {
        'hello': 'hello',
        'swim': 'swim',
        'lunch': 'lunch',
        'potato': 'potato',
        'name': 'name',
    }

    // STUFF_IN_SPANISH: {
    //
    //   //input translate api Spanish
    //     'swim': 'nadar',
    //     'hello': 'hola',
    //     'lunch': 'almuerzo'
    //     'potato': 'potato'
    //     },
};
